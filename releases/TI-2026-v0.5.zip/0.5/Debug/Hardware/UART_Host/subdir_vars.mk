################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Hardware/UART_Host/uart_host.c 

C_DEPS += \
./Hardware/UART_Host/uart_host.d 

OBJS += \
./Hardware/UART_Host/uart_host.o 

OBJS__QUOTED += \
"Hardware/UART_Host/uart_host.o" 

C_DEPS__QUOTED += \
"Hardware/UART_Host/uart_host.d" 

C_SRCS__QUOTED += \
"../Hardware/UART_Host/uart_host.c" 


