################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Hardware/MPU9250/mpu9250.c \
../Hardware/MPU9250/sw_i2c.c 

C_DEPS += \
./Hardware/MPU9250/mpu9250.d \
./Hardware/MPU9250/sw_i2c.d 

OBJS += \
./Hardware/MPU9250/mpu9250.o \
./Hardware/MPU9250/sw_i2c.o 

OBJS__QUOTED += \
"Hardware/MPU9250/mpu9250.o" \
"Hardware/MPU9250/sw_i2c.o" 

C_DEPS__QUOTED += \
"Hardware/MPU9250/mpu9250.d" \
"Hardware/MPU9250/sw_i2c.d" 

C_SRCS__QUOTED += \
"../Hardware/MPU9250/mpu9250.c" \
"../Hardware/MPU9250/sw_i2c.c" 


