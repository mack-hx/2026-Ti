################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Hardware/TB6612/tb6612.c 

C_DEPS += \
./Hardware/TB6612/tb6612.d 

OBJS += \
./Hardware/TB6612/tb6612.o 

OBJS__QUOTED += \
"Hardware/TB6612/tb6612.o" 

C_DEPS__QUOTED += \
"Hardware/TB6612/tb6612.d" 

C_SRCS__QUOTED += \
"../Hardware/TB6612/tb6612.c" 


