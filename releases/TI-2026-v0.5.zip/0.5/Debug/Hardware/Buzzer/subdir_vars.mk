################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Hardware/Buzzer/buzzer.c 

C_DEPS += \
./Hardware/Buzzer/buzzer.d 

OBJS += \
./Hardware/Buzzer/buzzer.o 

OBJS__QUOTED += \
"Hardware/Buzzer/buzzer.o" 

C_DEPS__QUOTED += \
"Hardware/Buzzer/buzzer.d" 

C_SRCS__QUOTED += \
"../Hardware/Buzzer/buzzer.c" 


