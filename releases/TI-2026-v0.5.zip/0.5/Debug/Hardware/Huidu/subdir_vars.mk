################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Hardware/Huidu/huidu.c 

C_DEPS += \
./Hardware/Huidu/huidu.d 

OBJS += \
./Hardware/Huidu/huidu.o 

OBJS__QUOTED += \
"Hardware/Huidu/huidu.o" 

C_DEPS__QUOTED += \
"Hardware/Huidu/huidu.d" 

C_SRCS__QUOTED += \
"../Hardware/Huidu/huidu.c" 


