################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Hardware/Encoder/encoder.c 

C_DEPS += \
./Hardware/Encoder/encoder.d 

OBJS += \
./Hardware/Encoder/encoder.o 

OBJS__QUOTED += \
"Hardware/Encoder/encoder.o" 

C_DEPS__QUOTED += \
"Hardware/Encoder/encoder.d" 

C_SRCS__QUOTED += \
"../Hardware/Encoder/encoder.c" 


