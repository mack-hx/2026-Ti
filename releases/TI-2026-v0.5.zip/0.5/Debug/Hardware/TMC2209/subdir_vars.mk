################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Hardware/TMC2209/tmc2209.c 

C_DEPS += \
./Hardware/TMC2209/tmc2209.d 

OBJS += \
./Hardware/TMC2209/tmc2209.o 

OBJS__QUOTED += \
"Hardware/TMC2209/tmc2209.o" 

C_DEPS__QUOTED += \
"Hardware/TMC2209/tmc2209.d" 

C_SRCS__QUOTED += \
"../Hardware/TMC2209/tmc2209.c" 


