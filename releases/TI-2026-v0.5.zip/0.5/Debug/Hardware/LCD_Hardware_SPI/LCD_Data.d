# FIXED

Hardware/LCD_Hardware_SPI/LCD_Data.o: \
 ../Hardware/LCD_Hardware_SPI/LCD_Data.c \
 ../Hardware/LCD_Hardware_SPI/LCD_Data.h

../Hardware/LCD_Hardware_SPI/LCD_Data.h:
