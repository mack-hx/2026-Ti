import time
import os
import sys

from media.sensor import *
from media.display import *
from media.media import *
from machine import FPIOA
from machine import Pin
from machine import PWM
from machine import Timer
from machine import TOUCH
from machine import UART

sensor = None

try:
    # 先初始化FPIOA与UART，保证即使后续传感器/显示初始化异常也能看到串口自检
    fpioa = FPIOA()
    fpioa.set_function(11, FPIOA.UART2_TXD)
    fpioa.set_function(12, FPIOA.UART2_RXD)
    uart2 = UART(UART.UART2, 115200)
    fpioa.set_function(50, FPIOA.UART3_TXD)
    fpioa.set_function(51, FPIOA.UART3_RXD)
    uart3 = UART(UART.UART3, 115200)
    try:
        uart2.write(b"BOOT UART2\r\n")
    except Exception:
        pass
    try:
        uart3.write(b"BOOT UART3\r\n")
    except Exception:
        pass

    # 激光控制：GPIO47 -> PWM3（参考 https://wiki.lckfb.com/zh-hans/lushan-pi-k230/basic/pwm.html §7.1 §9.6）
    # GPIO47 位于排针物理引脚 12，3-4-5 频率组；激光是简单开关，用 1kHz/0%-100% 占空比二值控制
    LASER_PIN = 47
    LASER_PWM_CH = 3
    LASER_FREQ = 1000
    LASER_DUTY_ON = 65535
    LASER_DUTY_OFF = 0
    laser_fpioa = FPIOA()
    laser_fpioa.set_function(LASER_PIN, getattr(FPIOA, f"PWM{LASER_PWM_CH}"))
    laser_pwm = PWM(LASER_PWM_CH)
    laser_pwm.freq(LASER_FREQ)
    laser_pwm.duty_u16(LASER_DUTY_OFF)
    print("[INFO] 激光初始化完成: GPIO{} -> PWM{} @ {}Hz".format(LASER_PIN, LASER_PWM_CH, LASER_FREQ))

    # 移除PID/舵机/激光相关实现

    sensor = Sensor(width=1920, height=1080)
    sensor.reset()

    # 鼠标悬停在函数上可以查看允许接收的参数
    sensor.set_framesize(width=1920, height=1080)
    sensor.set_pixformat(Sensor.RGB565)

    Display.init(Display.ST7701, to_ide=True, width=800, height=480)
    # 初始化媒体管理器
    MediaManager.init()
    # 启动 sensor
    sensor.run()

    fpioa = FPIOA()
    fpioa.help()
    # 设置按键
    fpioa.set_function(53, FPIOA.GPIO53)
    key = Pin(53, Pin.IN, Pin.PULL_DOWN)

    # GPIO53 作为按键

    clock = time.clock()

    # 按键去抖与沿触发
    KEY_DEBOUNCE_MS = 50
    key_last_state = 0
    key_last_change_ms = time.ticks_ms()

    # 状态标识，死循环中会根据不同的flag值执行相应的逻辑
    # flag = 1 识别激光点
    # flag = 2 阈值编辑
    # flag = 4 激光控制模式：持续检测黑框和激光位置
    flag = 0
    laser_control_mode = False  # 激光控制模式标志

    # 初始化中心点（保留，仅用于显示或调试）
    c_x = 320
    c_y = 320
    # 最近一次检测到的黑框中心坐标（用于持续显示）
    last_rect_cx = None
    last_rect_cy = None
    # 上一次正常的激光位置坐标（用于激光检测不到时的数据发送）
    last_laser_cx = None
    last_laser_cy = None

    # 裁剪图像的ROI，格式为(x, y, w, h)，加宽为640x480并靠右200像素
    cut_roi = (660, 300, 640, 480)

    # 向屏幕输出图像，脱机运行时可以选择注释img.compress_for_ide()来提升性能
    # show_img_2_screen 增加 try/except：K230 的 VO 层在某些情况下会因 layer 属性
    # 设置失败（异常 "set vo layer attr failed 2"）导致整个脚本崩溃退出。
    # 这里捕获异常后跳过当帧显示，避免一个偶发失败把阈值编辑模式整段退出。
    def show_img_2_screen():
        global img
        if(img.height()>480 or img.width() > 800):
            scale = max(img.height() // 480, img.width() // 800) + 1
            img.midpoint_pool(scale, scale)
#        img.compress_for_ide()
        try:
            Display.show_image(img, x=(800-img.width())//2, y=(480-img.height())//2)
        except Exception as e:
            print("[WARN] show_image 失败 (跳过): {}".format(e))

    # 统一的文本绘制封装（使用 draw_string_advanced 以支持中文）
    def draw_text(target_img, x, y, height_px, text, color=(255, 255, 255)):
        target_img.draw_string_advanced(x, y, height_px, text, color=color)

    # 简易文本宽度估算（等宽近似）用于右侧数值靠右显示
    def estimate_text_width(height_px, text):
        return int(len(str(text)) * height_px * 0.6)

    # 触摸计数器，达到一定的数值后开启阈值编辑模式，防止误触
    touch_counter = 0

    # 触摸屏初始化
    tp = TOUCH(0)

    # 存储阈值
    threshold_dict = {'rect': [(71, 255)], 'red_point':[(47, 99, 24, 48, -79, -59)]}
    # 清空阈值（可以注释掉，这里只是为了演示阈值编辑功能）
#    threshold_dict['rect'] = []
#    threshold_dict['red_point'] = []


    while True:
        clock.tick()
        os.exitpoint()

#串口收发信息
        # 读取UART2命令（来自MSPM0G3507）
        info2 = uart2.read()
        if info2 is not None:
            txt = None
            try:
                txt = info2.decode()
            except Exception:
                try:
                    txt = info2.decode('utf-8', 'ignore')
                except Exception:
                    txt = None
            if txt is not None:
                print(txt)
                if '激光打开' in txt:
                    laser_control_mode = True
                    flag = 4
                    # 由 K230 直接控制激光：GPIO47/PWM3 输出满占空比
                    try:
                        laser_pwm.duty_u16(LASER_DUTY_ON)
                        print("[INFO] 激光打开 (GPIO{} PWM duty={})".format(LASER_PIN, LASER_DUTY_ON))
                    except Exception as e:
                        print("[WARN] 激光打开失败: {}".format(e))
                elif '激光关闭' in txt:
                    laser_control_mode = False
                    flag = 0
                    # 关闭激光：PWM3 占空比置零
                    try:
                        laser_pwm.duty_u16(LASER_DUTY_OFF)
                        print("[INFO] 激光关闭 (GPIO{} PWM duty={})".format(LASER_PIN, LASER_DUTY_OFF))
                    except Exception as e:
                        print("[WARN] 激光关闭失败: {}".format(e))

        info3 = uart3.read()
        if info3 is not None:
            try:
                print(info3.decode())
            except Exception:
                try:
                    print(info3.decode('utf-8', 'ignore'))
                except Exception:
                    print(info3)

        # 本地按键触发一次矩形检测（保留原调试能力）
        if key.value() == 1:
            time.sleep_ms(2000)
            for i in range(5):
                img = sensor.snapshot(chn=CAM_CHN_ID_0)
                img = img.copy(roi=cut_roi)

                img_rect = img.to_grayscale(copy=True)
                img_rect = img_rect.binary(threshold_dict['rect'])
                rects = img_rect.find_rects(threshold=10000)
                if not rects == None:
                    for rect in rects:
                        corner = rect.corners()
                        img.draw_line(corner[0][0], corner[0][1], corner[1][0], corner[1][1], color=(0, 255, 0), thickness=5)
                        img.draw_line(corner[2][0], corner[2][1], corner[1][0], corner[1][1], color=(0, 255, 0), thickness=5)
                        img.draw_line(corner[2][0], corner[2][1], corner[3][0], corner[3][1], color=(0, 255, 0), thickness=5)
                        img.draw_line(corner[0][0], corner[0][1], corner[3][0], corner[3][1], color=(0, 255, 0), thickness=5)

                        c_x = sum([corner[k][0] for k in range(4)])/4
                        c_y = sum([corner[k][1] for k in range(4)])/4

                # 检测到两个框就说明检测大概率正确，切换flag=1
                if len(rects) == 2:
                    show_img_2_screen()
                    print("center_point: {}".format([round(c_x), round(c_y)]))
                    # 发送中心点坐标到UART2
                    try:
                        coord_msg = "{} {}\r\n".format(round(c_x), round(c_y))
                        uart2.write(coord_msg.encode())
                    except Exception:
                        pass
                    # 更新最近一次黑框中心
                    last_rect_cx = int(round(c_x))
                    last_rect_cy = int(round(c_y))
                    flag = 1
                    time.sleep_ms(500)
                    break
            if flag == 0:
                print("识别错误")
                # 发送识别错误信息到UART2
                try:
                    uart2.write(b"识别错误\r\n")
                except Exception:
                    pass

        # flag=1仅识别激光点并显示，不进行PID运算
        elif flag == 1:
            img = sensor.snapshot(chn=CAM_CHN_ID_0)
            img = img.copy(roi=cut_roi)
            blobs = img.find_blobs(threshold_dict['red_point'], False,\
                                x_stride=1, y_stride=1, \
                                pixels_threshold=20, margin=False)
            for blob in blobs:
                img.draw_rectangle(blob.x(), blob.y(), blob.w(), blob.h(), color=(0, 255, 0), thickness=2, fill=False)
                c_x = blob.x() + blob.w() / 2
                c_y = blob.y() + blob.h() / 2
                break
            show_img_2_screen()

        # 如果flag = 2，则启动阈值调整功能
        elif flag == 2:
            # 激光由 K230 本地 GPIO47/PWM3 控制（阈值模式下不强制开关，由 MSPM0 命令控制）

            # 在退出阈值模式前，主动 deinit 一次 Display，让 K230 的 VO layer 完全释放；
            # 防止 flag=2 之前累积的 show_image 在 VO 层占用的 layer 没回收，导致后续
            # 800x480 全屏重绘时出现 "set vo layer attr failed 2" 异常。
            try:
                Display.deinit()
            except Exception:
                pass
            try:
                Display.init(Display.ST7701, to_ide=True, width=800, height=480)
            except Exception as e:
                print("[WARN] Display 重新初始化失败: {}".format(e))

            # 清空当前的阈值
            for key_ in threshold_dict.keys():
                threshold_dict[key_] = []

            button_color = (150, 150, 150)
            text_color = (0, 0, 0)

            # 创建一个画布，用来绘制按钮 (整个 flag=2 期间复用此画布，不再每帧 new)
            canvas = image.Image(800, 480, image.RGB565)
            canvas.draw_rectangle(0, 0, 800, 480, color=(255, 255, 255), thickness=2, fill=True)


            # 按钮--返回，编辑完成后返回
            canvas.draw_rectangle(0, 0, 160, 40, color=button_color, thickness=2, fill=True)
            draw_text(canvas, 0+50, 0, 30, "返回", color=text_color)

            # 按钮--切换，切换编辑的阈值对象
            canvas.draw_rectangle(800-160, 0, 160, 40, color=button_color, thickness=2, fill=True)
            draw_text(canvas, 800-160+50, 0, 30, "切换", color=text_color)

            # 按钮--归位，滑块归位
            canvas.draw_rectangle(0, 480-40, 160, 40, color=button_color, thickness=2, fill=True)
            draw_text(canvas, 0+50, 480-40, 30, "归位", color=text_color)

            # 按钮--保存，将当前阈值添加到阈值列表中
            canvas.draw_rectangle(800-160, 480-40, 160, 40, color=button_color, thickness=2, fill=True)
            draw_text(canvas, 800-160+50, 480-40, 30, "保存", color=text_color)
            # 绘制12个按钮，对应了6个滑块的控制
            for j in [0, 800 - 160]:
                for i in range(60, 420, 60):
                    canvas.draw_rectangle(j, i, 160, 40, color=button_color, thickness=2, fill=True)

            # 定义一个函数，判断按下的按钮是哪一个，滑块按钮左边依次为0~5，右边依次为6~11
            def witch_key(x, y):
                if x < 160:
                    if y < 40:
                        return "return"
                    if y > 480 - 40:
                        return "reset"
                    if not y > 60:
                        return None
                    if (y - 60) % 60 < 40:
                        return str((y - 60) // 60)
                elif x > 800-160:
                    if y < 40:
                        return "change"
                    if y > 480 - 40:
                        return "save"
                    if not y > 60:
                        return None
                    if (y - 60) % 60 < 40:
                        return str((y - 60) // 60 + 6)
                return None

            # 可以调多个阈值
            threshold_mode_lst = list(threshold_dict.keys())
            threshold_mode = 'rect'
            threshold_current = [0, 255, 0, 255, 0, 255]

            while True:
                # 复用 canvas：先把"中心图像区"清白 (200..640 x, 0..480 y)，再贴图，再补四角按钮+标签
                # 这样不需要每帧 new 800x480 大画布，可避免 VO layer 被反复申请/释放
                canvas.draw_rectangle(200, 0, 640, 480, color=(255, 255, 255), thickness=1, fill=True)

                img_ = sensor.snapshot(chn=CAM_CHN_ID_0)
                img_ = img_.copy(roi=cut_roi)
#                print(threshold_mode)
                if threshold_mode == 'rect':
                    img_ = img_.to_grayscale()
                    img_ = img_.binary([threshold_current[:2]])
                    img_ = img_.to_rgb565()
                elif threshold_mode == 'red_point':
                    img_ = img_.binary([[i - 128 for i in threshold_current]])
                    img_ = img_.to_rgb565()
                canvas.draw_image(img_, (800-img_.width()) // 2, (480-img_.height()) // 2)
                img_ = None  # 释放引用，帮助 K230 内存回收

                # 重新绘制四角功能按钮灰框与文字，避免被中心图像覆盖
                canvas.draw_rectangle(0, 0, 160, 40, color=button_color, thickness=2, fill=True)
                draw_text(canvas, 0+50, 0, 30, "返回", color=text_color)
                canvas.draw_rectangle(800-160, 0, 160, 40, color=button_color, thickness=2, fill=True)
                draw_text(canvas, 800-160+50, 0, 30, "切换", color=text_color)
                canvas.draw_rectangle(0, 480-40, 160, 40, color=button_color, thickness=2, fill=True)
                draw_text(canvas, 0+50, 480-40, 30, "归位", color=text_color)
                canvas.draw_rectangle(800-160, 480-40, 160, 40, color=button_color, thickness=2, fill=True)
                draw_text(canvas, 800-160+50, 480-40, 30, "保存", color=text_color)

                # 为中间按钮绘制左右文字：左列显示阈值名称，右列显示当前值
                label_names = ["L小", "L大", "A小", "A大", "B小", "B大"]
                for idx, y in enumerate(range(60, 420, 60)):
                    # 先清除旧文字区域，避免叠影
                    canvas.draw_rectangle(0, y, 160, 30, color=(255, 255, 255), thickness=1, fill=True)
                    canvas.draw_rectangle(800-160, y, 160, 30, color=(255, 255, 255), thickness=1, fill=True)
                    # 左侧列标签
                    draw_text(canvas, 10, y, 24, label_names[idx], color=text_color)
                    # 右侧列数值，统一以 -128..128 显示
                    value = threshold_current[idx] - 128
                    value_text = str(value)
                    text_w = estimate_text_width(24, value_text)
                    draw_text(canvas, 800 - 10 - text_w, y, 24, value_text, color=text_color)

                points = tp.read()
                if len(points) > 0:
                    # 判断按下了哪个键
                    button_ = witch_key(points[0].x, points[0].y)
                    if button_:
                        # 如果是返回键
                        if button_ == "return":
                            flag = 0
                            # 重置长按计数并等待抬手，避免立即再次进入阈值界面
                            touch_counter = 0
                            # 退出阈值模式后再次 deinit/init Display，让主循环重新拿到一个干净的 VO layer
                            try:
                                Display.deinit()
                            except Exception:
                                pass
                            try:
                                Display.init(Display.ST7701, to_ide=True, width=800, height=480)
                            except Exception:
                                pass
                            start_ms = time.ticks_ms()
                            while len(tp.read()) > 0 and time.ticks_diff(time.ticks_ms(), start_ms) < 1000:
                                time.sleep_ms(20)
                            time.sleep_ms(200)
                            break
                        # 如果是切换键
                        elif button_ == "change":
                            # 切换阈值对象（边沿触发），并等待抬手避免连续触发
                            threshold_mode = threshold_mode_lst[(threshold_mode_lst.index(threshold_mode) + 1) % len(threshold_mode_lst)]
                            canvas.draw_rectangle(200, 200, 300, 40, color=button_color, thickness=2, fill=True)
                            draw_text(canvas, 200, 200, 30, "调整:{}".format(threshold_mode), color=text_color)
                            time.sleep_ms(300)
                            start_ms = time.ticks_ms()
                            while len(tp.read()) > 0 and time.ticks_diff(time.ticks_ms(), start_ms) < 1000:
                                time.sleep_ms(20)
                        # 如果是归位键
                        elif button_ == "reset":
                            threshold_current = [0, 255, 0, 255, 0, 255]
                            canvas.draw_rectangle(200, 200, 300, 40, color=button_color, thickness=2, fill=True)
                            draw_text(canvas, 200, 200, 30, "滑块归零", color=text_color)
                            time.sleep_ms(3000)
                        # 如果是保存键
                        elif button_ == "save":
                            if threshold_mode == 'red_point':
                                threshold_dict[threshold_mode].append([i - 128 for i in threshold_current])
                            elif threshold_mode == 'rect':
                                threshold_dict[threshold_mode].append(threshold_current[:2])
                            canvas.draw_rectangle(200, 200, 300, 40, color=button_color, thickness=2, fill=True)
                            draw_text(canvas, 200, 200, 30, "保存成功", color=text_color)
                            time.sleep_ms(3000)
                        else:
                            print("OK")
                            if int(button_) >= 6:
                                threshold_current[int(button_)-6] = min(255, threshold_current[int(button_)-6]+2)
                            elif int(button_) < 6:
                                threshold_current[int(button_)] = max(0, threshold_current[int(button_)]-2)
#                print(threshold_current)
                # 把画布推给全局 img，让 show_img_2_screen 用现有 VO layer 直接贴图，
                # 不再 new Image()，从根上避免 VO layer 反复申请导致 "set vo layer attr failed 2"
                img = canvas
                show_img_2_screen()


        

        # flag=4：激光控制模式，持续检测黑框和激光位置并实时发送
        elif flag == 4:
            img = sensor.snapshot(chn=CAM_CHN_ID_0)
            img = img.copy(roi=cut_roi)
            
            # 检测黑框
            img_rect = img.to_grayscale(copy=True)
            img_rect = img_rect.binary(threshold_dict['rect'])
            rects = img_rect.find_rects(threshold=10000)
            
            # 检测激光点
            blobs = img.find_blobs(threshold_dict['red_point'], False,
                                x_stride=1, y_stride=1,
                                pixels_threshold=20, margin=False)
            
            rect_cx = None
            rect_cy = None
            laser_cx = None
            laser_cy = None
            
            # 处理黑框检测结果
            if rects is not None and len(rects) > 0:
                # 取面积最大的矩形作为目标
                best = None
                best_area = 0
                for r in rects:
                    c = r.corners()
                    area = abs((c[1][0]-c[0][0])*(c[2][1]-c[1][1]))
                    if area > best_area:
                        best = r
                        best_area = area
                if best is not None:
                    c = best.corners()
                    rect_cx = sum([c[k][0] for k in range(4)])/4
                    rect_cy = sum([c[k][1] for k in range(4)])/4
                    # 绘制黑框
                    img.draw_line(c[0][0], c[0][1], c[1][0], c[1][1], color=(0,255,0), thickness=3)
                    img.draw_line(c[2][0], c[2][1], c[1][0], c[1][1], color=(0,255,0), thickness=3)
                    img.draw_line(c[2][0], c[2][1], c[3][0], c[3][1], color=(0,255,0), thickness=3)
                    img.draw_line(c[0][0], c[0][1], c[3][0], c[3][1], color=(0,255,0), thickness=3)
                    img.draw_circle(int(rect_cx), int(rect_cy), 4, color=(0,255,0), thickness=2, fill=False)
            
            # 处理激光点检测结果
            if blobs:
                for blob in blobs:
                    laser_cx = blob.x() + blob.w() / 2
                    laser_cy = blob.y() + blob.h() / 2
                    img.draw_rectangle(blob.x(), blob.y(), blob.w(), blob.h(), color=(255, 0, 0), thickness=2, fill=False)
                    img.draw_circle(int(laser_cx), int(laser_cy), 3, color=(255,0,0), thickness=2, fill=False)
                    break
            
            # 发送位置信息到MSPM0
            # X轴：黑框中心位置（让黑框中心始终在画面中心）
            # Y轴：激光和黑框中心的相对位置
            if rect_cx is not None and rect_cy is not None:
                try:
                    if laser_cx is not None and laser_cy is not None:
                        # 检测到激光和黑框：发送黑框中心x，激光相对黑框的y偏移
                        y_offset = laser_cy - rect_cy  # 激光相对于黑框中心的y偏移
                        msg = "{} {}\r\n".format(int(rect_cx), int(y_offset))
                        uart2.write(msg.encode())
                        # 记录上一次正常的激光位置
                        last_laser_cx = int(laser_cx)
                        last_laser_cy = int(laser_cy)
                        # 调试信息
                        draw_text(img, 0, 30, 16, "Laser OK: {} {}".format(int(rect_cx), int(y_offset)), color=(0, 255, 0))
                    else:
                        # 只检测到黑框，激光检测不到
                        if last_laser_cx is not None and last_laser_cy is not None:
                            # 使用上一次的y偏移
                            y_offset = last_laser_cy - rect_cy
                            msg = "{} {}\r\n".format(int(rect_cx), int(y_offset))
                            uart2.write(msg.encode())
                            # 调试信息
                            draw_text(img, 0, 30, 16, "Fake Y: {} {}".format(int(rect_cx), int(y_offset)), color=(255, 255, 0))
                        else:
                            # 没有历史激光位置，发送黑框中心x和0偏移
                            msg = "{} 0\r\n".format(int(rect_cx))
                            uart2.write(msg.encode())
                            # 调试信息
                            draw_text(img, 0, 30, 16, "No History: {} 0".format(int(rect_cx)), color=(255, 255, 0))
                except Exception:
                    pass
            else:
                # 连黑框都检测不到，发送停止信号
                try:
                    msg = "-1 -1\r\n"
                    uart2.write(msg.encode())
                    # 调试信息
                    draw_text(img, 0, 30, 16, "No Target: -1 -1", color=(255, 0, 0))
                except Exception:
                    pass
            
            # 显示FPS与图像
            draw_text(img, 0, 0, 24, "FPS: {}".format(clock.fps()), color=(255, 0, 0))
            show_img_2_screen()

        else:
            img = sensor.snapshot(chn=CAM_CHN_ID_0)
            img = img.copy(roi=cut_roi)
            draw_text(img, 0, 0, 24, "FPS: {}".format(clock.fps()), color=(255, 0, 0))
            # 若存在最近一次黑框中心，则持续显示其坐标文本与两个中心标记
            if last_rect_cx is not None and last_rect_cy is not None:
                # 文本：显示四个坐标（黑框中心x,y 屏幕中心x,y），每个坐标3位数，用空格分隔
                sx2 = img.width()/2
                sy2 = img.height()/2
                coord_text = "{:3d} {:3d} {:3d} {:3d}".format(last_rect_cx, last_rect_cy, int(sx2), int(sy2))
                draw_text(img, 0, 28, 24, coord_text)
                # 两个中心点标记：绿为黑框中心，红为屏幕中心
                img.draw_circle(int(last_rect_cx), int(last_rect_cy), 4, color=(0,255,0), thickness=2, fill=False)
                img.draw_circle(int(sx2), int(sy2), 4, color=(255,0,0), thickness=2, fill=False)
            show_img_2_screen()

        # 实现一个长按屏幕进入阈值编辑模式的效果
        points = tp.read()
        if len(points) > 0:
            touch_counter += 1
            if touch_counter > 20:
                flag = 2
            print(points[0].x)
        else:
            touch_counter -= 2
            touch_counter = max(0, touch_counter)

except KeyboardInterrupt as e:
    print("用户停止: ", e)
except BaseException as e:
    print(f"异常: {e}")
finally:
    # 释放激光 PWM 资源：先置零占空比，再 deinit 释放通道（参考 PWM 教程 §8.4）
    try:
        laser_pwm.duty_u16(LASER_DUTY_OFF)
        laser_pwm.deinit()
        print("[INFO] 激光 PWM 已释放 (GPIO{} PWM{})".format(LASER_PIN, LASER_PWM_CH))
    except Exception as e:
        print("[WARN] 激光 PWM 释放失败: {}".format(e))
    if isinstance(sensor, Sensor):
        sensor.stop()
    Display.deinit()
    os.exitpoint(os.EXITPOINT_ENABLE_SLEEP)
    time.sleep_ms(100)
    MediaManager.deinit()

