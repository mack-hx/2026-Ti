################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Each subdirectory must supply rules for building sources it contributes
Hardware/TB6612/%.o: ../Hardware/TB6612/%.c $(GEN_OPTS) | $(GEN_FILES) $(GEN_MISC_FILES)
	@echo 'GNU Compiler - building file: "$<"'
	"/Users/m/ti/gcc_arm_none_eabi_9_2_1/bin/arm-none-eabi-gcc-9.2.1" -c @"device.opt"  -mcpu=cortex-m0plus -march=armv6-m -mthumb -mfloat-abi=soft -I"/Volumes/Moving/work/01_code/01_Competition/01_ELE_com/2026-TI-Em/2026-TI/0.4" -I"/Volumes/Moving/work/01_code/01_Competition/01_ELE_com/2026-TI-Em/2026-TI/0.4/Debug" -I"/Volumes/Moving/work/01_code/01_Competition/01_ELE_com/2026-TI-Em/2026-TI/0.4/Hardware/LCD_Hardware_SPI" -I"/Volumes/Moving/work/01_code/01_Competition/01_ELE_com/2026-TI-Em/2026-TI/0.4/Hardware/PD42S1" -I"/Volumes/Moving/work/01_code/01_Competition/01_ELE_com/2026-TI-Em/2026-TI/0.4/Hardware/Encoder" -I"/Volumes/Moving/work/01_code/01_Competition/01_ELE_com/2026-TI-Em/2026-TI/0.4/Hardware/UART_Host" -I"/Volumes/Moving/work/01_code/01_Competition/01_ELE_com/2026-TI-Em/2026-TI/0.4/Hardware/Buzzer" -I"/Volumes/Moving/work/01_code/01_Competition/01_ELE_com/2026-TI-Em/2026-TI/0.4/Hardware/TMC2209" -I"/Volumes/Moving/work/01_code/01_Competition/01_ELE_com/2026-TI-Em/2026-TI/0.4/Hardware/Huidu" -I"/Volumes/Moving/work/01_code/01_Competition/01_ELE_com/2026-TI-Em/2026-TI/0.4/Hardware/TB6612" -I"/Volumes/Moving/work/01_code/01_Competition/01_ELE_com/2026-TI-Em/2026-TI/0.4/Hardware/MPU9250" -I"/Users/m/ti/mspm0_sdk_2_10_00_04/source/third_party/CMSIS/Core/Include" -I"/Users/m/ti/mspm0_sdk_2_10_00_04/source" -I"/Users/m/ti/gcc_arm_none_eabi_9_2_1/arm-none-eabi/include/newlib-nano" -I"/Users/m/ti/gcc_arm_none_eabi_9_2_1/arm-none-eabi/include" -O2 -ffunction-sections -fdata-sections -g -gdwarf-3 -gstrict-dwarf -Wall -MMD -MP -MF"Hardware/TB6612/$(basename $(<F)).d_raw" -MT"$(@)" -std=c99 $(GEN_OPTS__FLAG) -o"$@" "$<"
	@echo 'Finished building: "$<"'
	@echo ' '


